from Modelos.AbstractModelo import AbstractModelo
class Mesa(AbstractModelo):
    pass