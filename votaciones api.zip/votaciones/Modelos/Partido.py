from Modelos.AbstractModelo import AbstractModelo
class Partido(AbstractModelo):
    pass