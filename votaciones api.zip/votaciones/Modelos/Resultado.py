from Modelos.AbstractModelo import AbstractModelo
class Resultado(AbstractModelo):
    pass