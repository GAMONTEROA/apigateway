package proyecto.Ciclo4.gestionusuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionusuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
